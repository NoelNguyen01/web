// ==========================================
// KHU TỰ TRỊ NOEL NGUYỄN - CLIENT APP LOGIC
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // Web Audio Synth for notifications
  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  function playNotificationSound() {
    if (!state.soundEnabled) return;
    try {
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    } catch (e) {}
  }

  // Application State
  const state = {
    socket: null,
    currentUser: null,
    adminToken: sessionStorage.getItem('noel_admin_token') || null,
    selectedFile: null,
    isUploading: false,
    soundEnabled: true,
    membersVisible: true
  };

  // DOM Elements
  const loginModal = document.getElementById('loginModal');
  const loginForm = document.getElementById('loginForm');
  const loginUsername = document.getElementById('loginUsername');
  const loginPasscode = document.getElementById('loginPasscode');
  const loginError = document.getElementById('loginError');
  const loginErrorText = document.getElementById('loginErrorText');

  const adminModal = document.getElementById('adminModal');
  const adminAuthForm = document.getElementById('adminAuthForm');
  const adminPassInput = document.getElementById('adminPassInput');
  const adminError = document.getElementById('adminError');
  const adminErrorText = document.getElementById('adminErrorText');
  const headerAdminBtn = document.getElementById('headerAdminBtn');
  const adminBtnLabel = document.getElementById('adminBtnLabel');
  const closeAdminModalBtn = document.getElementById('closeAdminModalBtn');
  const clearChatBtn = document.getElementById('clearChatBtn');

  const botSettingsBtn = document.getElementById('botSettingsBtn');
  const botModal = document.getElementById('botModal');
  const closeBotModalBtn = document.getElementById('closeBotModalBtn');
  const botKeyForm = document.getElementById('botKeyForm');
  const geminiKeyInput = document.getElementById('geminiKeyInput');
  const botKeyStatus = document.getElementById('botKeyStatus');
  const botTypingIndicator = document.getElementById('botTypingIndicator');
  const quickBotTagBtn = document.getElementById('quickBotTagBtn');

  const userChip = document.getElementById('userChip');
  const userChipAvatar = document.getElementById('userChipAvatar');
  const userChipName = document.getElementById('userChipName');
  const soundToggleBtn = document.getElementById('soundToggleBtn');
  const soundIcon = document.getElementById('soundIcon');
  const toggleMembersBtn = document.getElementById('toggleMembersBtn');
  const membersSidebar = document.getElementById('membersSidebar');
  const onlineUserList = document.getElementById('onlineUserList');
  const onlineCount = document.getElementById('onlineCount');
  const headerOnlineCount = document.getElementById('headerOnlineCount');

  const messageArea = document.getElementById('messageArea');
  const messagesList = document.getElementById('messagesList');
  const bottomAnchor = document.getElementById('bottomAnchor');
  const chatForm = document.getElementById('chatForm');
  const messageInput = document.getElementById('messageInput');
  const fileInput = document.getElementById('fileInput');
  const attachBtn = document.getElementById('attachBtn');
  const uploadPreviewCard = document.getElementById('uploadPreviewCard');
  const previewFileName = document.getElementById('previewFileName');
  const previewFileSize = document.getElementById('previewFileSize');
  const previewIconBox = document.getElementById('previewIconBox');
  const cancelUploadBtn = document.getElementById('cancelUploadBtn');
  const progressContainer = document.getElementById('progressContainer');
  const progressBarFill = document.getElementById('progressBarFill');
  const progressPercentText = document.getElementById('progressPercentText');
  const dragDropOverlay = document.getElementById('dragDropOverlay');

  const emojiToggleBtn = document.getElementById('emojiToggleBtn');
  const emojiPalette = document.getElementById('emojiPalette');

  const lightboxModal = document.getElementById('lightboxModal');
  const lightboxImage = document.getElementById('lightboxImage');
  const lightboxDownloadBtn = document.getElementById('lightboxDownloadBtn');
  const closeLightboxBtn = document.getElementById('closeLightboxBtn');

  // Initialize Socket.IO with auto-reconnection
  state.socket = io({
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 1000
  });

  // Pre-fill username from session
  const savedUser = sessionStorage.getItem('noel_username');
  const savedPass = sessionStorage.getItem('noel_passcode');
  if (savedUser) loginUsername.value = savedUser;
  if (savedPass) loginPasscode.value = savedPass;

  // Auto-join on connect / reconnect
  state.socket.on('connect', () => {
    const user = sessionStorage.getItem('noel_username');
    const pass = sessionStorage.getItem('noel_passcode');
    if (user && pass) {
      attemptLogin(user, pass);
    }
  });

  // Global ESC key listener to close modals
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      adminModal.classList.add('hidden');
      botModal.classList.add('hidden');
      lightboxModal.classList.add('hidden');
      lightboxModal.classList.remove('flex');
      emojiPalette.classList.add('hidden');
    }
  });

  // 1. Join Room
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = loginUsername.value.trim();
    const passcode = loginPasscode.value.trim();

    if (!username) return showLoginError('Vui lòng nhập tên người dùng');
    if (!passcode) return showLoginError('Vui lòng nhập mật khẩu phòng');

    attemptLogin(username, passcode);
  });

  function attemptLogin(username, passcode) {
    loginError.classList.add('hidden');
    state.socket.emit('join_room', { username, passcode });
  }

  function showLoginError(msg) {
    loginErrorText.textContent = msg;
    loginError.classList.remove('hidden');
  }

  state.socket.on('join_success', (data) => {
    state.currentUser = data.user;
    sessionStorage.setItem('noel_username', data.user.username);
    sessionStorage.setItem('noel_passcode', loginPasscode.value.trim());

    loginModal.classList.add('hidden');
    updateUserHeaderChip();

    // Check if resuming admin
    if (state.adminToken) {
      state.socket.emit('resume_admin', { adminToken: state.adminToken });
    }

    // Render history
    messagesList.innerHTML = '';
    data.history.forEach(msg => appendMessage(msg, false));
    scrollToBottom();

    renderOnlineUsers(data.onlineUsers);
  });

  state.socket.on('join_error', (msg) => {
    showLoginError(msg);
  });

  // 2. Admin Authentication
  function openAdminModal() {
    adminError.classList.add('hidden');
    adminPassInput.value = '';
    adminModal.classList.remove('hidden');
    adminPassInput.focus();
  }

  function closeAdminModal() {
    adminModal.classList.add('hidden');
  }

  headerAdminBtn.addEventListener('click', () => {
    if (state.currentUser && state.currentUser.isAdmin) {
      alert('Bạn đang giữ quyền Quản trị viên tối cao của Khu tự trị Noel Nguyễn 👑');
    } else {
      openAdminModal();
    }
  });

  closeAdminModalBtn.addEventListener('click', closeAdminModal);

  adminAuthForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const pass = adminPassInput.value.trim();
    if (!pass) return;
    state.socket.emit('verify_admin', { passcode: pass });
  });

  state.socket.on('admin_success', ({ token }) => {
    state.adminToken = token;
    sessionStorage.setItem('noel_admin_token', token);
    if (state.currentUser) state.currentUser.isAdmin = true;

    closeAdminModal();
    applyAdminUI();

    document.querySelectorAll('.msg-actions').forEach(el => el.classList.remove('hidden'));
  });

  state.socket.on('admin_error', (msg) => {
    adminErrorText.textContent = msg;
    adminError.classList.remove('hidden');
  });

  function applyAdminUI() {
    adminBtnLabel.textContent = 'Admin 👑';
    headerAdminBtn.className = 'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-amber-500 to-rose-600 text-white shadow-lg shadow-amber-500/30 border border-amber-300 transition-all';
    clearChatBtn.classList.remove('hidden');
    clearChatBtn.classList.add('flex');
    updateUserHeaderChip();
  }

  // Clear Chat action (Admin only)
  clearChatBtn.addEventListener('click', () => {
    if (!state.currentUser?.isAdmin || !state.adminToken) return;
    if (confirm('⚠️ Bạn có chắc muốn dọn sạch toàn bộ tin nhắn trong phòng chat không?')) {
      state.socket.emit('clear_chat', { adminToken: state.adminToken });
    }
  });

  state.socket.on('chat_cleared', ({ by }) => {
    messagesList.innerHTML = '';
    const notice = document.createElement('div');
    notice.className = 'p-3 my-2 text-center text-xs text-amber-400 bg-amber-500/10 rounded-lg border border-amber-500/30 font-medium';
    notice.innerHTML = `🧹 Toàn bộ tin nhắn đã được dọn sạch bởi Quản trị viên <b>${escapeHTML(by)}</b>.`;
    messagesList.appendChild(notice);
  });

  // 3. Bot AI Settings & Interaction
  botSettingsBtn.addEventListener('click', () => {
    botKeyStatus.classList.add('hidden');
    botModal.classList.remove('hidden');
    geminiKeyInput.focus();
  });

  closeBotModalBtn.addEventListener('click', () => {
    botModal.classList.add('hidden');
  });

  botKeyForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const key = geminiKeyInput.value.trim();
    if (!key) return;
    state.socket.emit('update_gemini_key', { apiKey: key });
  });

  state.socket.on('gemini_key_updated', () => {
    botKeyStatus.classList.remove('hidden');
    setTimeout(() => {
      botModal.classList.add('hidden');
    }, 1200);
  });

  quickBotTagBtn.addEventListener('click', () => {
    if (!messageInput.value.includes('@bot')) {
      messageInput.value = '@bot ' + messageInput.value;
    }
    messageInput.focus();
  });

  state.socket.on('bot_typing', ({ isTyping }) => {
    if (isTyping) {
      botTypingIndicator.classList.remove('hidden');
      botTypingIndicator.classList.add('flex');
    } else {
      botTypingIndicator.classList.add('hidden');
      botTypingIndicator.classList.remove('flex');
    }
    scrollToBottom();
  });

  // 4. Online Users
  state.socket.on('user_joined', ({ onlineUsers }) => renderOnlineUsers(onlineUsers));
  state.socket.on('user_left', ({ onlineUsers }) => renderOnlineUsers(onlineUsers));
  state.socket.on('user_role_changed', ({ onlineUsers }) => renderOnlineUsers(onlineUsers));

  function renderOnlineUsers(users) {
    if (!users) return;
    if (headerOnlineCount) headerOnlineCount.textContent = users.length;
    if (onlineCount) onlineCount.textContent = users.length;
    onlineUserList.innerHTML = '';

    users.forEach(u => {
      const userItem = document.createElement('div');
      userItem.className = 'flex items-center gap-2.5 px-2 py-1.5 rounded-md hover:bg-white/5 cursor-pointer transition';

      const avatarColor = getAvatarColor(u.username);
      const isUserAdmin = u.isAdmin;

      userItem.innerHTML = `
        <div class="relative shrink-0">
          <div class="w-8 h-8 rounded-full ${avatarColor} flex items-center justify-center font-bold text-xs text-white shadow-sm">
            ${getInitials(u.username)}
          </div>
          <div class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-discord-sidebar"></div>
        </div>
        <div class="min-w-0 flex-1">
          <div class="text-sm font-semibold truncate flex items-center gap-1.5 ${isUserAdmin ? 'admin-name' : 'text-gray-200'}">
            <span>${escapeHTML(u.username)}</span>
            ${isUserAdmin ? '<span class="admin-badge">👑 ADMIN</span>' : ''}
          </div>
          <div class="text-[10px] text-gray-400 truncate">Trực tuyến</div>
        </div>
      `;
      onlineUserList.appendChild(userItem);
    });

    if (window.lucide) window.lucide.createIcons();
  }

  function updateUserHeaderChip() {
    if (!state.currentUser) return;
    if (userChipName) userChipName.textContent = state.currentUser.username;
    if (userChipAvatar) {
      userChipAvatar.textContent = getInitials(state.currentUser.username);
      userChipAvatar.className = `w-7 h-7 rounded-full ${getAvatarColor(state.currentUser.username)} flex items-center justify-center font-bold text-xs text-white shadow-sm`;
    }
    if (userChip) {
      userChip.classList.remove('hidden');
      userChip.classList.add('flex');
    }
  }

  // 5. Drag & Drop Files
  window.addEventListener('dragover', (e) => {
    e.preventDefault();
    dragDropOverlay.classList.remove('hidden');
    dragDropOverlay.classList.add('flex');
  });

  window.addEventListener('dragleave', (e) => {
    if (e.relatedTarget === null) {
      dragDropOverlay.classList.add('hidden');
      dragDropOverlay.classList.remove('flex');
    }
  });

  window.addEventListener('drop', (e) => {
    e.preventDefault();
    dragDropOverlay.classList.add('hidden');
    dragDropOverlay.classList.remove('flex');

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  });

  // Attach button trigger
  attachBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => {
    if (fileInput.files && fileInput.files.length > 0) {
      handleFileSelected(fileInput.files[0]);
    }
  });

  function handleFileSelected(file) {
    state.selectedFile = file;
    previewFileName.textContent = file.name;
    previewFileSize.textContent = formatBytes(file.size);

    const isImg = file.type.startsWith('image/');
    previewIconBox.innerHTML = isImg 
      ? '<i data-lucide="image" class="w-4 h-4 text-rose-400"></i>'
      : '<i data-lucide="file-text" class="w-4 h-4 text-discord-blurple"></i>';

    uploadPreviewCard.classList.remove('hidden');
    progressContainer.classList.add('hidden');
    progressBarFill.style.width = '0%';
    progressPercentText.textContent = '0%';

    if (window.lucide) window.lucide.createIcons();
    messageInput.focus();
  }

  cancelUploadBtn.addEventListener('click', () => {
    clearSelectedFile();
  });

  function clearSelectedFile() {
    state.selectedFile = null;
    fileInput.value = '';
    uploadPreviewCard.classList.add('hidden');
    progressContainer.classList.add('hidden');
  }

  // Upload file with XMLHttpRequest for progress tracking
  function uploadFileWithProgress(file) {
    return new Promise((resolve, reject) => {
      progressContainer.classList.remove('hidden');
      state.isUploading = true;

      const xhr = new XMLHttpRequest();
      const formData = new FormData();
      formData.append('file', file);

      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
          const percent = Math.round((e.loaded / e.total) * 100);
          progressBarFill.style.width = percent + '%';
          progressPercentText.textContent = percent + '%';
        }
      });

      xhr.addEventListener('load', () => {
        state.isUploading = false;
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const res = JSON.parse(xhr.responseText);
            resolve(res.file);
          } catch (err) {
            reject(new Error('Phản hồi server không hợp lệ'));
          }
        } else {
          reject(new Error('Tải tệp thất bại (HTTP ' + xhr.status + ')'));
        }
      });

      xhr.addEventListener('error', () => {
        state.isUploading = false;
        reject(new Error('Lỗi mạng khi tải tệp'));
      });

      xhr.open('POST', '/api/upload');
      xhr.send(formData);
    });
  }

  // 6. Send Message Submit
  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!state.currentUser) return;
    if (state.isUploading) return;

    const text = messageInput.value.trim();
    const hasFile = !!state.selectedFile;

    if (!text && !hasFile) return;

    let uploadedFile = null;
    if (hasFile) {
      try {
        uploadedFile = await uploadFileWithProgress(state.selectedFile);
      } catch (err) {
        alert('Tải file lên thất bại: ' + err.message);
        return;
      }
    }

    state.socket.emit('send_message', {
      text: text,
      file: uploadedFile,
      adminToken: state.adminToken
    });

    messageInput.value = '';
    clearSelectedFile();
  });

  // Receive new message
  state.socket.on('new_message', (msg) => {
    appendMessage(msg, true);
    if (msg.username !== state.currentUser?.username) {
      playNotificationSound();
    }
  });

  // Message deleted
  state.socket.on('message_deleted', ({ messageId }) => {
    const el = document.getElementById(messageId);
    if (el) {
      el.style.opacity = '0';
      el.style.transform = 'scale(0.95)';
      setTimeout(() => el.remove(), 200);
    }
  });

  // Append a message to DOM
  function appendMessage(msg, scroll = true) {
    const canDelete = state.currentUser?.isAdmin && !msg.isBot;
    const isBot = msg.isBot;

    const item = document.createElement('div');
    item.id = msg.id;
    item.className = 'message-item message-enter flex gap-3 px-2 py-1.5 rounded-lg group';

    const avatarHtml = isBot
      ? `<div class="w-9 h-9 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center font-bold text-sm text-white shadow">🤖</div>`
      : `<div class="w-9 h-9 rounded-full ${getAvatarColor(msg.username)} flex items-center justify-center font-bold text-xs text-white shadow">${getInitials(msg.username)}</div>`;

    // Attachment render
    let attachmentHtml = '';
    if (msg.file) {
      const isImg = msg.file.mimeType && msg.file.mimeType.startsWith('image/');
      if (isImg) {
        attachmentHtml = `
          <div class="mt-2">
            <img src="${msg.file.url}" alt="${escapeHTML(msg.file.originalName)}" class="image-attachment" loading="lazy" onclick="window.openLightbox('${msg.file.url}', '${escapeHTML(msg.file.originalName)}')">
          </div>
        `;
      } else {
        attachmentHtml = `
          <div class="mt-2">
            <div class="attachment-card">
              <div class="w-9 h-9 rounded bg-discord-chat flex items-center justify-center text-discord-blurple shrink-0">
                <i data-lucide="file" class="w-5 h-5"></i>
              </div>
              <div class="min-w-0 flex-1">
                <div class="text-xs font-semibold text-white truncate" title="${escapeHTML(msg.file.originalName)}">${escapeHTML(msg.file.originalName)}</div>
                <div class="text-[11px] text-gray-400">${formatBytes(msg.file.fileSize)}</div>
              </div>
              <a href="${msg.file.url}" download="${escapeHTML(msg.file.originalName)}" class="p-1.5 hover:bg-white/10 text-gray-300 hover:text-white rounded transition shrink-0" title="Tải về">
                <i data-lucide="download" class="w-4 h-4"></i>
              </a>
            </div>
          </div>
        `;
      }
    }

    const textFormatted = msg.text ? formatMessageText(escapeHTML(msg.text)) : '';

    let roleBadge = '';
    if (msg.isAdmin) {
      roleBadge = '<span class="admin-badge">👑 ADMIN</span>';
    } else if (isBot) {
      roleBadge = '<span class="bot-badge">🤖 BOT</span>';
    }

    item.innerHTML = `
      <div class="relative shrink-0 pt-0.5">
        ${avatarHtml}
      </div>
      <div class="flex-1 min-w-0">
        <div class="flex items-baseline gap-2 mb-0.5">
          <span class="font-semibold text-sm ${msg.isAdmin ? 'admin-name' : (isBot ? 'bot-name' : 'text-white')}">
            ${escapeHTML(msg.username)}
          </span>
          ${roleBadge}
          <span class="text-[10px] text-gray-400">${msg.timestamp}</span>
        </div>

        ${msg.text ? `<div class="text-xs sm:text-sm text-gray-200 leading-relaxed break-words">${textFormatted}</div>` : ''}
        ${attachmentHtml}
      </div>

      <!-- Delete button for admin -->
      <div class="msg-actions ${canDelete ? '' : 'hidden'} absolute right-3 top-2 bg-discord-sidebar border border-discord-border rounded px-1.5 py-0.5 shadow items-center gap-1">
        <button onclick="window.requestDeleteMessage('${msg.id}')" title="Xóa tin nhắn (Admin)" class="p-1 text-gray-400 hover:text-rose-400 transition">
          <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
        </button>
      </div>
    `;

    messagesList.appendChild(item);
    if (window.lucide) window.lucide.createIcons();

    if (scroll) scrollToBottom();
  }

  window.requestDeleteMessage = function(messageId) {
    if (!state.currentUser?.isAdmin || !state.adminToken) return;
    state.socket.emit('delete_message', { messageId, adminToken: state.adminToken });
  };

  // Lightbox
  window.openLightbox = function(url, filename) {
    lightboxImage.src = url;
    lightboxDownloadBtn.href = url;
    lightboxDownloadBtn.download = filename || 'image.png';
    lightboxModal.classList.remove('hidden');
    lightboxModal.classList.add('flex');
  };

  closeLightboxBtn.addEventListener('click', () => {
    lightboxModal.classList.add('hidden');
    lightboxModal.classList.remove('flex');
    lightboxImage.src = '';
  });

  lightboxModal.addEventListener('click', (e) => {
    if (e.target === lightboxModal) {
      lightboxModal.classList.add('hidden');
      lightboxModal.classList.remove('flex');
      lightboxImage.src = '';
    }
  });

  // Emoji Palette
  emojiToggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    emojiPalette.classList.toggle('hidden');
  });

  document.querySelectorAll('.emoji-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      messageInput.value += btn.textContent;
      emojiPalette.classList.add('hidden');
      messageInput.focus();
    });
  });

  document.addEventListener('click', () => {
    emojiPalette.classList.add('hidden');
  });

  // Sound Toggle
  soundToggleBtn.addEventListener('click', () => {
    state.soundEnabled = !state.soundEnabled;
    soundIcon.setAttribute('data-lucide', state.soundEnabled ? 'volume-2' : 'volume-x');
    if (window.lucide) window.lucide.createIcons();
  });

  // Members sidebar toggle
  toggleMembersBtn.addEventListener('click', () => {
    state.membersVisible = !state.membersVisible;
    membersSidebar.classList.toggle('hidden', !state.membersVisible);
  });

  function scrollToBottom() {
    bottomAnchor.scrollIntoView({ behavior: 'smooth' });
  }

  function formatBytes(bytes, decimals = 1) {
    if (!+bytes) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
  }

  function getInitials(name) {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  function getAvatarColor(name) {
    const colors = [
      'bg-indigo-600', 'bg-rose-600', 'bg-emerald-600', 'bg-amber-600',
      'bg-purple-600', 'bg-cyan-600', 'bg-teal-600', 'bg-pink-600'
    ];
    let hash = 0;
    for (let i = 0; i < (name || '').length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  }

  function escapeHTML(str) {
    return (str || '').replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }

  function formatMessageText(text) {
    // Markdown bold **bold**
    let formatted = text.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
    // Code `code`
    formatted = formatted.replace(/`(.*?)`/g, '<code class="bg-black/30 px-1 py-0.5 rounded text-amber-300 font-mono text-xs">$1</code>');
    // URLs
    const urlPattern = /(\b(https?:\/\/|www\.)[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    formatted = formatted.replace(urlPattern, (url) => {
      const fullUrl = url.startsWith('http') ? url : 'http://' + url;
      return `<a href="${fullUrl}" target="_blank" rel="noopener noreferrer" class="text-discord-blurple hover:underline">${url}</a>`;
    });
    // Newlines
    formatted = formatted.replace(/\n/g, '<br>');
    return formatted;
  }
});
